let  n=[1,2,3]
localStorage.setItem("numbers",n)
localStorage.getItem("numbers")
localStorage.removeItem("numbers")