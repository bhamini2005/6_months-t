
function handle(){
    document.getElementById("head").style.color="white"
    document.getElementsByTagName("body")[0].style.background= "black";
    document.getElementById("btn").style.color= "black";
    document.getElementById("btn").style.background= "white";
    document.getElementById("btn1").style.color="white"
    document.getElementById("btn1").style.background="black"
    

}

function handle2(){
    document.getElementById("head").style.color="black"
    document.getElementsByTagName("body")[0].style.background= "white";
    document.getElementById("btn1").style.color= "black";
    document.getElementById("btn1").style.background= "white";
    document.getElementById("btn").style.color="white"
    document.getElementById("btn").style.background="black"
    
}


    let size= 10;
    function abc(){
        size +=10;
        document.getElementById("size").style.fontSize = size + "px";
    }
     
let count=0
    function bc(){
        count++
        document.getElementById("count").innerHTML=count;     
    }
      function dc(){
        count--
        document.getElementById("count").innerHTML=count;
      }  

    
