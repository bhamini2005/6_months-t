document.getElementById("head").style.color = "black";
document.getElementById("head").innerHTML="hyy arshita"
document.getElementById("head").style.fontSize = "100px";
document.getElementById("head").style.fontFamily = "Arial";
document.getElementById("head").style.textTransform = "uppercase";


let items=document.getElementsByClassName("text");
for(let i=0;i<items.length; i++){
    items[i].style.color="green"
     items[0].textContent="bhamini"
     items[1].textContent="divyanshi"
     

} 
let  home=document.getElementsByTagName("p")
for(let i=0;i<home.length;i++){
    home[i].style.color="pink"
}
document.querySelector(".name").style.color = "green";
document.querySelector("#bh").style.color = "purple";
document.querySelector("p").style.color = "teal";

let item=document.querySelectorAll(".name")

for(let i=0;i<item.length;i++){
    let j=i+2
    item[i].textContent="hello everybody..my name is pennywise"
    item[j].style.color ="blue";}